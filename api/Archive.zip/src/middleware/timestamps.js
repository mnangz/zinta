// var Visitor = require('../models/visitor');

// Visitor.post('save', (doc) => {
//     console.log('%s has been saved', doc._id);
//   });
  
//   Visitor.pre('updateOne', () => {
//     this.update({},{ $set: { updatedAt: new Date() } });
//   });