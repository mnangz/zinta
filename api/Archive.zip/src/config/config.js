module.exports = {
    jwtSecret: 'booking-mate',
    // db: 'mongodb+srv://mnangagwatamuka:GKOvkQu04keGSTVE@cluster.mongodb.net/booking-mate?retryWrites=true&w=majority',
    db: 'mongodb://mnangagwatamuka:GKOvkQu04keGSTVE@ac-fethdl6-shard-00-00.q1cronb.mongodb.net:27017,ac-fethdl6-shard-00-01.q1cronb.mongodb.net:27017,ac-fethdl6-shard-00-02.q1cronb.mongodb.net:27017/?ssl=true&replicaSet=atlas-ous5cv-shard-0&authSource=admin&retryWrites=true&w=majority'
};